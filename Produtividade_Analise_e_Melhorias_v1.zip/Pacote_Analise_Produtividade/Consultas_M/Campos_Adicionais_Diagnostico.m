let
    Fonte = stg_SharePoint{[Id="ec87b29f-d485-465c-9706-384693de3275"]}[Items],
    Nomes = Table.ColumnNames(Fonte),
    Campos = {"Mobilizacao", "Codigo_Matriz_Snapshot", "Area_Snapshot", "Modalidade", "Tipo_Mediacao_Snapshot", "Turno", "Campus_Polo", "Origem_Registro", "Matriculas_Reais", "Matriculas_Reais_Confirmadas"},
    Tabela = Table.FromList(Campos, Splitter.SplitByNothing(), {"Campo"}),
    Presenca = Table.AddColumn(Tabela, "Disponivel", each List.Contains(Nomes, [Campo]), type logical),
    Resultado = Table.AddColumn(Presenca, "Tratamento", each if [Disponivel] then "Coluna disponível; conferir preenchimento" else if [Campo] = "Mobilizacao" then "Obrigatória: bloqueia DimTurma até corrigir o nome" else "Opcional ausente: preenchida com nulo; não representa ausência no RM", type text)
in
    Resultado