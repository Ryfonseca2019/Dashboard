let
    Colunas = Table.SelectColumns(DimTurma, {"Mobilizacao"}),
    Valores = Table.Distinct(Colunas),
    Resultado = Table.Sort(Valores, {{"Mobilizacao", Order.Ascending}})
in
    Resultado