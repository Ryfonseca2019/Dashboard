let
    Valores = Table.Distinct(Table.SelectColumns(DimTurma, {"Mobilizacao"})),
    Resultado = Table.Sort(Valores, {{"Mobilizacao", Order.Ascending}})
in
    Resultado