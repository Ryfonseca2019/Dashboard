(v as any) as nullable text =>
    if v = null then null
    else if Value.Is(v, type list) then Text.Combine(List.RemoveNulls(List.Transform(v, each @fxTextoDescritivo(_))), " | ")
    else if Value.Is(v, type table) then @fxTextoDescritivo(Table.ToRecords(v))
    else if Value.Is(v, type record) then
        let candidatos = {"lookupValue", "LookupValue", "Value", "value", "DisplayName", "displayName", "Title", "title", "Email", "email"},
            valores = List.RemoveNulls(List.Transform(candidatos, each Record.FieldOrDefault(v, _, null))),
            primeiro = if List.IsEmpty(valores) then error "Campo estruturado sem texto reconhecido; confira o formato da coluna no SharePoint." else valores{0}
        in @fxTextoDescritivo(primeiro)
    else Text.Trim(Text.From(v))