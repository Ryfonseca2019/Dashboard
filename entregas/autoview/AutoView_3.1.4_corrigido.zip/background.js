'use strict';
const BASE={version:3,institutional:false,selectorOpen:false,enabled:false,maintenanceAll:false,profiles:Array.from({length:4},(_,i)=>({id:i+1,name:`Monitor ${i+1}`,displayIndex:i,showSeconds:30,refreshSeconds:3600,maintenance:false,paused:false,items:[],image:'',windowId:null,screenTabId:null,activeIndex:0,lastSwitch:0,issue:'',activeSince:0})),refreshJob:null,events:[]};
const safeUrl=u=>{try{const x=new URL(u);return ['http:','https:'].includes(x.protocol)?x.href:null;}catch{return null}};
let busy=false;
// A single writer for each read/modify/write transaction, including browser events.
// Rejections do not poison subsequent commands. Read-only status bypasses the queue.
let transaction=Promise.resolve();
function serialize(label,task){
  const queued=performance.now();
  const result=transaction.then(async()=>{
    const start=performance.now();
    console.debug('[AutoView perf]',label,{queueMs:+(start-queued).toFixed(2)});
    try{return await task()}finally{console.debug('[AutoView perf]',label,{executionMs:+(performance.now()-start).toFixed(2)})}
  });
  transaction=result.catch(()=>{});
  return result;
}
async function measured(stage,task){const start=performance.now();try{return await task()}finally{console.debug('[AutoView perf]',stage,{ms:+(performance.now()-start).toFixed(2)})}}
async function read(){return (await measured('storage:read',()=>chrome.storage.local.get('autoview'))).autoview||structuredClone(BASE)}
async function write(s){const start=performance.now();await chrome.storage.local.set({autoview:s});console.debug('[AutoView perf] storage:write',{ms:+(performance.now()-start).toFixed(2)})}
const log=(s,msg)=>{s.events=[{at:Date.now(),message:msg},...(s.events||[])].slice(0,120)};
async function displays(){const ds=await chrome.system.display.getInfo();return ds.filter(d=>d.isEnabled!==false&&d.bounds).sort((a,b)=>a.bounds.left-b.bounds.left||a.bounds.top-b.bounds.top)}
async function validWindow(id){if(!Number.isInteger(id))return false;try{await chrome.windows.get(id);return true}catch{return false}}
async function ensureWindow(s,p){if(await validWindow(p.windowId))return p.windowId;const ds=await displays(),d=ds[p.displayIndex];if(!d){p.issue='Monitor de destino não encontrado';return null}const b=d.workArea||d.bounds;const w=await chrome.windows.create({url:chrome.runtime.getURL('screen.html?profile='+p.id),type:'normal',focused:false,left:b.left,top:b.top,width:Math.max(450,b.width),height:Math.max(350,b.height),state:'normal'});p.windowId=w.id;p.screenTabId=w.tabs?.[0]?.id||null;p.activeIndex=0;p.lastSwitch=Date.now();p.activeSince=Date.now();p.issue='';try{await chrome.windows.update(w.id,{state:'fullscreen'})}catch(e){p.issue='Tela cheia não aplicada: '+e.message}log(s,`Janela do perfil ${p.id} aberta`);return w.id}
async function getTabs(p){if(!await validWindow(p.windowId))return [];return chrome.tabs.query({windowId:p.windowId})}
async function ensureScreen(p){let ts=await getTabs(p);const u=chrome.runtime.getURL('screen.html');let screen=ts.find(t=>t.url?.startsWith(u));if(!screen){screen=await chrome.tabs.create({windowId:p.windowId,url:u+'?profile='+p.id,active:false})}p.screenTabId=screen.id;return screen.id}
async function showScreen(p){if(!await validWindow(p.windowId))return;try{const id=await ensureScreen(p);await chrome.tabs.update(id,{active:true})}catch{}}
async function ensureDashboardTabs(p){const ts=await getTabs(p);const screenURL=chrome.runtime.getURL('screen.html');const configured=p.items.filter(x=>x.enabled!==false&&safeUrl(x.url));const owned=ts.filter(t=>t.url&&!t.url.startsWith(screenURL)&&!t.url.startsWith('edge://')&&!t.url.startsWith('chrome-extension://'));for(const t of owned){if(!configured.some(x=>x.url===t.url)) { /* Never close tabs not owned by this extension. */ }}
for(const item of configured){if(!Number.isInteger(item.tabId)||!ts.some(t=>t.id===item.tabId)){const existing=ts.find(t=>t.url===item.url&&!configured.some(x=>x!==item&&x.tabId===t.id));if(existing)item.tabId=existing.id;else{const t=await chrome.tabs.create({windowId:p.windowId,url:item.url,active:false});item.tabId=t.id}}}
return configured}
async function showDashboard(s,p,idx){const list=await ensureDashboardTabs(p);if(!list.length){await showScreen(p);return}const i=((idx%list.length)+list.length)%list.length;p.activeIndex=i;try{await chrome.tabs.update(list[i].tabId,{active:true});p.lastSwitch=Date.now();p.activeSince=Date.now()}catch(e){p.issue=e.message}}
// Seleção prioritária: ativar a aba cadastrada sem percorrer/criar todos os dashboards.
async function showDashboardFast(p,idx){
  const list=p.items.filter(x=>x.enabled!==false&&safeUrl(x.url));
  if(!list.length)throw Error('O perfil não possui dashboards ativos');
  const i=((idx%list.length)+list.length)%list.length, item=list[i];
  let tab=null;
  if(Number.isInteger(item.tabId)){
    try{const candidate=await measured('tabs:get',()=>chrome.tabs.get(item.tabId));if(candidate.windowId===p.windowId)tab=candidate;}catch{}
  }
  if(!tab){
    const existing=await measured('tabs:query',()=>chrome.tabs.query({windowId:p.windowId}));
    tab=existing.find(t=>t.url===item.url&&!list.some(other=>other!==item&&other.tabId===t.id));
  }
  if(!tab){tab=await measured('tabs:create',()=>chrome.tabs.create({windowId:p.windowId,url:item.url,active:true}));}
  else await measured('tabs:activate',()=>chrome.tabs.update(tab.id,{active:true}));
  item.tabId=tab.id;p.activeIndex=i;p.lastSwitch=Date.now();p.activeSince=p.lastSwitch;
}
async function launch(){if(busy)return;busy=true;try{const s=await read();if(!s.enabled)return;const ds=await displays();if(ds.length<4){log(s,`Detectados somente ${ds.length} monitores; confira o Windows`)}for(const p of s.profiles){if(p.maintenance||s.maintenanceAll)continue;await ensureWindow(s,p);if(!await validWindow(p.windowId))continue;await showScreen(p);if(!s.institutional){await showDashboard(s,p,p.activeIndex||0)} }await write(s)}finally{busy=false}}
async function reconcile(){if(busy)return;busy=true;try{const s=await read();if(!s.enabled)return;for(const p of s.profiles){if(s.maintenanceAll||p.maintenance)continue;if(!await validWindow(p.windowId)){await ensureWindow(s,p);if(s.institutional){await showScreen(p)}else{await showScreen(p);await showDashboard(s,p,p.activeIndex||0)}continue}if(s.institutional){await showScreen(p);continue}if(p.paused||(p.id===1&&s.selectorOpen))continue;const list=p.items.filter(x=>x.enabled!==false&&safeUrl(x.url));if(!list.length)continue;const interval=Math.max(30,(list[p.activeIndex]?.showSeconds||p.showSeconds||30))*1000;if(Date.now()-(p.lastSwitch||0)>=interval){await showDashboard(s,p,(p.activeIndex+1)%list.length)}}await scheduleRefresh(s);await write(s)}finally{busy=false}}
async function scheduleRefresh(s){if(s.institutional||s.maintenanceAll||s.refreshJob)return;const now=Date.now();for(const p of s.profiles){if(p.maintenance||p.paused||!await validWindow(p.windowId))continue;const list=p.items.filter(x=>x.enabled!==false&&safeUrl(x.url));for(const item of list){const ms=Math.max(30,(item.refreshSeconds||p.refreshSeconds||3600))*1000;if(now-(item.lastRefresh||now)>=ms){const tabs=await getTabs(p);const active=tabs.find(t=>t.active)?.id;if(active===item.tabId&&(list.length>1||(p.id===1&&s.selectorOpen)))continue;try{if(active===item.tabId)await showScreen(p);s.refreshJob={profileId:p.id,itemId:item.id,tabId:item.tabId,started:now,returnToDashboard:active===item.tabId};await chrome.tabs.reload(item.tabId);log(s,`Atualização iniciada: ${item.name}`);return}catch(e){item.issue=e.message;s.refreshJob=null}}}}}
async function checkRefresh(){const s=await read();const j=s.refreshJob;if(!j)return;if(Date.now()-j.started>110000){const p=s.profiles.find(p=>p.id===j.profileId),item=p?.items.find(x=>x.id===j.itemId);if(item){item.issue='Tempo limite de carregamento';item.lastRefresh=Date.now()}s.refreshJob=null;log(s,'Timeout de atualização');await write(s)}}
chrome.tabs.onUpdated.addListener((tabId,change)=>serialize('tabs:updated',async()=>{if(change.status!=='complete')return;const s=await read(),j=s.refreshJob;if(!j||j.tabId!==tabId)return;const p=s.profiles.find(x=>x.id===j.profileId),item=p?.items.find(x=>x.id===j.itemId);if(!p||!item)return;item.lastRefresh=Date.now();item.issue='';s.refreshJob=null;await write(s);if(j.returnToDashboard){await chrome.alarms.create('return:'+p.id+':'+item.id,{when:Date.now()+10000})}}).catch(console.error));
chrome.alarms.onAlarm.addListener(a=>serialize('alarm:'+a.name,async()=>{try{if(a.name==='tick'){await reconcile();await checkRefresh()}else if(a.name.startsWith('return:')){const [,pid,iid]=a.name.split(':');const s=await read(),p=s.profiles.find(x=>x.id===Number(pid));if(!p||s.institutional||p.maintenance||p.paused)return;const item=p.items.find(x=>x.id===iid);if(!item)return;const list=p.items.filter(x=>x.enabled!==false&&safeUrl(x.url));const ix=list.findIndex(x=>x.id===iid);if(ix>=0&&await validWindow(p.windowId)){await showDashboard(s,p,ix);await write(s)}}}catch(e){console.error(e)}}).catch(console.error));
chrome.windows.onRemoved.addListener(id=>serialize('window:removed',async()=>{const s=await read(),p=s.profiles.find(x=>x.windowId===id);if(!p)return;p.windowId=null;p.screenTabId=null;log(s,`Janela do monitor ${p.id} fechada`);await write(s);if(s.enabled&&!s.maintenanceAll&&!p.maintenance)await chrome.alarms.create('tick',{periodInMinutes:.5,delayInMinutes:.5})}).catch(console.error));
chrome.runtime.onMessage.addListener((req,sender,respond)=>{const handle=async()=>{let s=await read();switch(req.type){case 'GET':respond({ok:true,state:s,displays:await displays()});return;
case 'HOST_STATUS':{const t=sender.tab;const host=!!(t&&s.enabled&&s.profiles[0]?.windowId===t.windowId);respond({ok:true,host,institutional:!!s.institutional,open:!!s.selectorOpen,profiles:host&&!s.institutional?s.profiles.map(p=>({id:p.id,name:p.name,paused:!!p.paused,maintenance:!!p.maintenance,available:!!p.windowId,items:p.items.filter(x=>x.enabled!==false&&safeUrl(x.url)).map(x=>({id:x.id,name:x.name,thumbnail:req.includeThumbnails?(x.thumbnail||null):null}))})):[]});return}
case 'SELECT_DASHBOARD':{if(s.institutional)throw Error('Modo Institucional ativo');if(!sender.tab||sender.tab.windowId!==s.profiles[0].windowId)throw Error('Comando permitido apenas no Monitor 1');const p=s.profiles.find(x=>x.id===Number(req.profileId));if(!s.enabled||!p||p.maintenance||s.maintenanceAll)throw Error('Monitor indisponível ou em manutenção');if(!await validWindow(p.windowId))throw Error('Janela do monitor indisponível');const list=p.items.filter(x=>x.enabled!==false&&safeUrl(x.url));const idx=list.findIndex(x=>x.id===req.itemId);if(idx<0)throw Error('Dashboard não encontrado');p.paused=true;s.selectorOpen=false;
// Persistir a pausa antes de ativar a aba: o ciclo de rotação não deve competir com o clique.
await write(s);
try{await showDashboardFast(p,idx)}catch(e){p.issue='Falha na seleção: '+e.message;await write(s);throw e}
log(s,`Seleção manual no Monitor ${p.id}: ${list[idx].name}`);
await write(s);respond({ok:true,message:`${list[idx].name} exibido no Monitor ${p.id}; rotação pausada`});return}
case 'SELECTOR_OPEN':{if(!sender.tab||sender.tab.windowId!==s.profiles[0].windowId)throw Error('Central disponível apenas no Monitor 1');if(s.institutional)throw Error('Controle institucional disponível na tela protegida');s.selectorOpen=!!req.open;await write(s);respond({ok:true});return}
case 'RESUME_PROFILE':{if(s.institutional)throw Error('Modo Institucional ativo');const p=s.profiles.find(x=>x.id===Number(req.profileId));if(!p)throw Error('Monitor inválido');p.paused=false;p.lastSwitch=Date.now();log(s,`Rotação retomada no Monitor ${p.id}`);await write(s);respond({ok:true});return}
case 'RESUME_ALL_PROFILES':{if(s.institutional)throw Error('Modo Institucional ativo');for(const p of s.profiles){p.paused=false;p.lastSwitch=Date.now()}log(s,'Rotações retomadas pelo operador');await write(s);respond({ok:true});return}

case 'SAVE':{const proposed=req.state;if(!proposed||!Array.isArray(proposed.profiles)||proposed.profiles.length!==4)throw Error('Configuração inválida');for(const p of proposed.profiles){p.items=(p.items||[]).filter(x=>safeUrl(x.url)).map(x=>({...x,url:safeUrl(x.url),lastRefresh:x.lastRefresh||Date.now()}));p.showSeconds=Math.max(30,Number(p.showSeconds)||30);p.refreshSeconds=Math.max(30,Number(p.refreshSeconds)||3600)}proposed.events=s.events;proposed.refreshJob=s.refreshJob;await write(proposed);respond({ok:true});return}
case 'START':s.enabled=true;await write(s);await launch();respond({ok:true});return;
case 'STOP':s.enabled=false;await write(s);respond({ok:true});return;
case 'INSTITUTIONAL':if(sender.tab&&sender.tab.windowId!==s.profiles[0].windowId)throw Error('Controle disponível apenas no Monitor 1');s.institutional=true;s.selectorOpen=false;log(s,'Modo institucional ativado');await write(s);for(const p of s.profiles)await showScreen(p);respond({ok:true});return;
case 'RESUME':if(sender.tab&&sender.tab.windowId!==s.profiles[0].windowId)throw Error('Controle disponível apenas no Monitor 1');s.institutional=false;s.selectorOpen=false;for(const p of s.profiles){p.paused=false;p.lastSwitch=Date.now()};log(s,'Modo institucional desativado');await write(s);for(const p of s.profiles){if(!p.maintenance&&!p.paused&&await validWindow(p.windowId)){await showDashboard(s,p,p.activeIndex||0)}}await write(s);respond({ok:true});return;
case 'PAUSE':{const p=s.profiles.find(x=>x.id===req.id);if(!p)throw Error('Perfil inválido');p.paused=!!req.paused;if(req.itemId){const idx=p.items.filter(x=>x.enabled!==false).findIndex(x=>x.id===req.itemId);if(idx>=0&&!s.institutional)await showDashboard(s,p,idx)}log(s,`Monitor ${p.id}: ${p.paused?'apresentador':'automático'}`);await write(s);respond({ok:true});return}
case 'MAINTENANCE':{const p=s.profiles.find(x=>x.id===req.id);if(!p)throw Error('Perfil inválido');p.maintenance=!!req.enabled;log(s,`Manutenção monitor ${p.id}: ${p.maintenance?'iniciada':'encerrada'}`);await write(s);if(!p.maintenance)await launch();respond({ok:true});return}
case 'REFRESH':{const p=s.profiles.find(x=>x.id===req.id),item=p?.items.find(x=>x.id===req.itemId);if(!item||s.institutional||p.paused||p.maintenance)throw Error('Atualização não autorizada neste estado');const t=(await getTabs(p)).find(x=>x.active);const hidden=t?.id===item.tabId;if(hidden)await showScreen(p);s.refreshJob={profileId:p.id,itemId:item.id,tabId:item.tabId,started:Date.now(),returnToDashboard:hidden};await write(s);await chrome.tabs.reload(item.tabId);respond({ok:true});return}
case 'OPEN_OPTIONS':await chrome.runtime.openOptionsPage();respond({ok:true});return;
default:throw Error('Comando desconhecido')}};
const job=['GET','HOST_STATUS'].includes(req.type)?handle():serialize('message:'+req.type,handle);
job.catch(e=>respond({ok:false,error:e.message}));return true});
chrome.commands.onCommand.addListener(command=>serialize('command:'+command,async()=>{if(command==='open_control'){await chrome.runtime.openOptionsPage()}if(command==='institutional'){const s=await read();s.institutional=true;await write(s);for(const p of s.profiles)await showScreen(p)}}).catch(console.error));
async function initialize(){const s=await read();for(const p of s.profiles){p.windowId=null;p.screenTabId=null;p.paused=false;p.maintenance=false;p.items.forEach(x=>x.lastRefresh=x.lastRefresh||Date.now())}s.maintenanceAll=false;s.refreshJob=null;s.selectorOpen=false;await write(s);await chrome.alarms.create('tick',{periodInMinutes:.5});if(s.enabled)await launch()}
chrome.runtime.onInstalled.addListener(details=>{serialize('installed',async()=>{const s=await read();if(details.reason==='install'){await initialize()}else{if(s.selectorOpen===undefined)s.selectorOpen=false;await write(s);await chrome.alarms.create('tick',{periodInMinutes:.5});if(s.enabled)await reconcile()}}).catch(console.error)});
chrome.runtime.onStartup.addListener(()=>{serialize('startup',initialize).catch(console.error)});
chrome.alarms.get('tick').then(a=>{if(!a)chrome.alarms.create('tick',{periodInMinutes:.5})});
