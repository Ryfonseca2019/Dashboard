# Planejamento de Turmas — UX v2

Esta versão substitui a UX v1, que apresentou ErrOpeningDocument_UnknownError ao abrir no Power Apps Studio.

## O que mudou na reconstrução

A v1 foi editada diretamente no pacote e não tinha sido aberta no Studio. A v2 foi reconstruída pelo Microsoft PowerPlatform CLI 2.14.1, no layout SourceCode, usando a base interna original. As alterações são carregadas a partir das fontes YAML, conforme o contrato da ferramenta oficial; todas as 25 entradas originais fora de Src foram preservadas byte a byte. Foi removida das fontes a propriedade de ordenação interna ZIndex, pois no YAML a ordem da lista Children define a sobreposição. As fontes foram lidas e regravadas pelo serializador da Microsoft.

O erro genérico informado pelo usuário não permite afirmar qual detalhe da v1 causou a falha. Esta reconstrução corrige a estratégia de empacotamento, mas a abertura no serviço ainda precisa ser confirmada.

## Melhorias mantidas

1. Diálogos de alterações não salvas nas saídas dos formulários de turma, planejamento, horário, evasão mensal e calendário. A troca de evento também pede confirmação quando há alterações. Não há nova proteção para fechar o navegador ou para os controles manuais da tela de parâmetros de evasão.
2. Lista nativa e edição de eventos do calendário na mesma sessão, sem links para reabrir o aplicativo.
3. Cinco seções no cadastro de turma e opção Ver todos os campos. Os campos e as regras de cálculo originais permanecem.
4. Pesquisa de matriz pelo início do código, com mensagem de ausência de resultados. A projeção da busca ainda está sujeita aos limites de resultados do Power Apps; valide com o volume real.

## Como abrir

1. Extraia o ZIP. O arquivo a abrir é App_Planejamento_Turmas_UX_v2.msapp.
2. Use o Power Apps Studio, opção de abrir um arquivo local de aplicativo de tela. Este MSAPP não é um pacote de importação de solução; não o envie para a importação de soluções ZIP.
3. Abra para edição como cópia de teste. A própria ferramenta oficial exige a primeira abertura para edição no Studio para validar aplicativos reconstruídos a partir de YAML.
4. Confira as conexões e execute o App Checker. Não substitua o aplicativo de produção antes de testar.
5. Teste: voltar com alterações e escolher continuar/descartar; navegar entre as cinco seções sem perder os valores; filtrar matriz e limpar a pesquisa; abrir e salvar edição de um evento existente sem duplicá-lo; trocar de evento com alterações pendentes.

Se continuar aparecendo ErrOpeningDocument_UnknownError, compare com a abertura do MSAPP original enviado nesta conversa. Informe se o original abre e qual etapa mostra o erro. O ID de sessão permite investigação pela Microsoft, mas não dá acesso automático aos logs nesta conversa.

## Verificações feitas

- Reconstrução e extração posterior pelo CLI oficial: passaram.
- Leitura e serialização das 13 fontes YAML pela biblioteca Microsoft.PowerPlatform.PowerApps.Persistence: passaram.
- Análise sintática de 6.546 expressões com Microsoft.PowerFx.Core: zero erros de sintaxe.
- Igualdade semântica das fontes após o ciclo de empacotamento/extração: passou.
- Integridade do MSAPP e preservação das entradas originais fora de Src: passaram.

Essas verificações não são a compilação completa do aplicativo. Não houve abertura no Power Apps Studio, checagem de tipos/vínculos com controles e fontes de dados, renderização no player nem gravação no SharePoint. O AppCheckerResult.sarif incluído no MSAPP continua sendo o resultado original e deve ser regenerado no Studio.

O arquivo Validacao_UX_v2.json registra as verificações e seus limites. Nenhum registro remoto foi alterado durante a preparação.
