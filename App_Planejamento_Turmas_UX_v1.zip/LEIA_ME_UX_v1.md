# App Planejamento de Turmas — UX v1

Arquivo para avaliação: **App_Planejamento_Turmas_UX_v1.msapp**.

Esta cópia implementa as quatro primeiras melhorias da tabela do parecer UX/UI. O arquivo original foi preservado. Nenhuma conexão foi executada e nenhum registro do SharePoint foi alterado nesta preparação.

## Alterações realizadas

1. **Proteção ao sair de formulários.** Voltar/Cancelar e acesso a Complementos verificam alterações não salvas nos formulários de turma, planejamento, horário e evasão mensal. O calendário também protege a saída, a limpeza do formulário e a troca para outro evento. O diálogo oferece “Continuar editando” ou “Descartar e continuar”. Os controles de fundo ficam desabilitados enquanto o diálogo está aberto, e há uma solicitação de foco no botão Continuar. A navegação é bloqueada durante a gravação dos formulários protegidos. Fechar o navegador ou usar comandos do host não foi coberto por uma nova regra de ConfirmExit; o comportamento depende do player.

2. **Edição do calendário na própria tela.** A tabela HTML antiga permanece no arquivo, mas oculta. Uma galeria nativa apresenta os registros com o botão “Editar evento”. A ação seleciona o ID e chama EditForm no formulário existente, sem link para outra instância do aplicativo. A tela distingue novo evento de edição, e Salvar tem estado de gravação. “Limpar / novo evento” também protege alterações pendentes.

3. **Cadastro de turma em cinco seções.** Curso e oferta; Datas e local; Vagas e matrículas; Evasão; Responsáveis e situação. Todos os 27 cartões originais foram preservados, incluindo campos condicionais. “Ver todos os campos” permite retornar a uma visão completa e rolável. Se a validação original frmTurma.Valid falhar, a visão completa é aberta. Os demais alertas de negócio continuam sendo os existentes. Trocar de seção não reinicia o formulário. Abrir o auxiliar de taxas conserva a turma em edição; os controles manuais da própria tela de taxas não receberam um novo diálogo de saída.

4. **Busca da matriz conectada.** A caixa de pesquisa foi movida do cabeçalho para a seção Curso e oferta. Ao digitar o início do código, a lista Matriz consulta Cad_Matrizes por Codigo_Matriz. Ao apagar, usa o Choices original. O resultado conserva o formato de lookup `{Id, Value}`, com o código no Value, conforme o esquema do arquivo. Há mensagem de ausência de resultados. O comportamento com muitas correspondências precisa ser validado, pois a projeção ForAll está sujeita aos limites do Power Apps; prefira um prefixo específico. Não foi implementada pesquisa por nome do curso nesta versão.

## Como avaliar com segurança

1. Baixe o MSAPP modificado.
2. Abra o Power Apps Studio e use a opção de abrir um aplicativo a partir de um arquivo local. Avalie como cópia de teste, sem substituir/publicar imediatamente o aplicativo de produção.
3. Confira as conexões e use fontes de teste para cenários que gravem dados. Se o Studio apontar erros de fórmula, interrompa a publicação e registre o controle e a mensagem para correção.
4. Execute o App Checker novamente. O resultado incluído dentro do MSAPP é o resultado original, anterior às alterações.
5. Realize as tarefas abaixo antes de publicar.

## Roteiro de validação

| Cenário | Resultado esperado |
|---|---|
| Alterar uma turma e clicar Voltar | Diálogo; continuar mantém os valores; descartar volta à lista |
| Alterar turma e abrir Complementos | Mesma proteção, sem saída silenciosa |
| Cancelar planejamento/horário/evasão com mudanças | Confirmação antes do descarte |
| Sair sem mudanças | Navegação direta |
| Trocar as cinco seções da turma | Valores preenchidos permanecem e os campos correspondentes aparecem |
| Consultar todos os campos | Todos os cartões normalmente disponíveis aparecem; condições originais continuam aplicadas |
| Tentar salvar turma inválida | Validação original preservada, com acesso à visão completa quando frmTurma.Valid falha |
| Salvar turma válida | Patch original e destino Complementos preservados |
| Pesquisar início de um código existente | Matriz lista códigos correspondentes; selecionar e salvar mantém ID/código corretos |
| Pesquisar código inexistente e depois limpar | Mensagem de ausência de resultados; lista original volta ao limpar |
| Editar turma com matriz já preenchida | Seleção existente continua correta antes/depois da pesquisa e ao salvar |
| Clicar Editar evento | Mesmo aplicativo, registro correto e formulário em edição |
| Alterar evento A e clicar Editar evento B | Diálogo; continuar mantém A; descartar abre B |
| Salvar edição do calendário | Atualiza o ID existente, sem criar outro registro |
| Limpar calendário com mudanças | Confirmação; descartar inicia um novo evento |
| Simular erro de conexão e tentar novamente | Mensagem de erro e botão de gravação recuperado |
| Navegar por teclado e testar diferentes tamanhos | Seções, diálogo e lista operáveis; foco e rolagem conferidos no player |

## Verificação executada neste ambiente

- Integridade ZIP/CRC do original e da cópia.
- Inventário de entradas e preservação byte a byte dos recursos não modificados.
- IDs e nomes únicos dos controles e consistência de seus pais.
- Consistência das propriedades entre JSON e YAML, respeitando o armazenamento interno dos eventos de galeria.
- Preservação dos DataFields, Defaults, Updates e regras Required dos cartões originais.
- Preservação das fórmulas de gravação de planejamento, horários e evasão. O Patch de turma permanece original; a única inserção nessa fórmula abre todos os campos quando frmTurma.Valid falha.
- Preservação das conexões, imagens e referências de dados.
- Conferência lexical de strings e delimitadores das fórmulas alteradas.

Resultado detalhado: `validation-results.json`.

**Limite essencial:** a edição foi feita diretamente nas representações JSON/YAML do pacote, sem empacotador oficial ou Power Apps Studio neste Linux. Os checks estruturais não substituem importação, compilação Power Fx, análise de delegação nem execução no player. Esta é uma versão candidata para avaliação no Studio; não foi validada para produção. Ajustes de renderização e compatibilidade podem ser necessários após a abertura.

## Arquivos técnicos

- `apply_ux.py`: reprodução da modificação a partir do original preservado neste ambiente.
- `validate_ux.py`: verificações estruturais executadas.
- `changes.json`: inventário de mudanças e hashes SHA-256.
- `modified/`: apenas as definições alteradas, para inspeção técnica.

Os scripts usam os caminhos desta sessão. Não foram instalados como setup do ambiente nem enviados ao repositório GitHub.
